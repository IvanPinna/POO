#include <iostream>
#include "tarjeta.hpp"

using namespace std;

void eliminarChar(Cadena& c, size_t pos)
{
  Cadena aux = c.substr(0, pos);

  if( (pos + 1) < c.length() )
    aux += Cadena(c, pos + 1);
  c = move(aux);
}

int main()
{
  Numero n("01234 56789 012   8");

  cout << n << endl;
  
}
