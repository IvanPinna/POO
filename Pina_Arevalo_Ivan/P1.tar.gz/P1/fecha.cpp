//PRACTICA 1

#include "fecha.hpp"
#include <iomanip>

Fecha::Fecha(int d, int m, int a) : dia_{d}, mes_{m}, anno_{a}
{
    
    if(dia_ == 0 || mes_ == 0 || anno_ == 0)
    {
        time_t now = time(0);
        tm * time = localtime(&now);

        if(dia_ == 0)
        dia_ = time->tm_mday;
        if(mes_ == 0)
            mes_ = time->tm_mon+1;
        if(anno_ == 0)
            anno_ = time->tm_year+1900;
    }

    validar();
}

Fecha::Fecha(const char * cadena)
{
    //int numchar = 0;
    if(sscanf(cadena, "%d/%d/%d", &dia_, &mes_, &anno_) == 3)
        *this = Fecha(dia_, mes_, anno_);
    else
        throw Invalida("Formato invalido");

    validar();
}

const int Fecha::AnnoMaximo{2037};
const int Fecha::AnnoMinimo{1902};

Fecha& Fecha::operator++()
{
    *this += 1;
    validar();
    return *this;
}

Fecha& Fecha::operator--()
{
    *this += -1;
    validar();
    return *this;
}

Fecha Fecha::operator++(int)
{
    Fecha copia(*this);
    *this += 1;
    validar();
    return copia;
}

Fecha Fecha::operator--(int)
{
    Fecha copia(*this);
    *this += -1;
    validar();
    return copia;
}

Fecha& Fecha::operator +=(int n)
{
    /*time_t now = time(0);
    tm * time = localtime(&now);

    dia_ += n;
    time->tm_mday = dia_;
    mktime(time);

    dia_ = time->tm_mday;
    mes_ = time->tm_mon + 1;
    anno_ = time->tm_year + 1900;*/
    
    tm time = {};
    
    time.tm_mday = dia_ + n;
    time.tm_mon = mes_  - 1;  
    time.tm_year = anno_ - 1900;
    //t_usuario.tm_isdst = -1;
        
    mktime(&time);
        
    dia_ = time.tm_mday;
    mes_ = time.tm_mon + 1;
    anno_ = time.tm_year + 1900;

    validar();

    return *this;
}

Fecha& Fecha::operator -=(int n)
{
    *this += -n;

    return *this;
}

bool operator ==(const Fecha& fecha1, const Fecha& fecha2)
{
    if(fecha1.dia() == fecha2.dia() && fecha1.mes() == fecha2.mes() && fecha1.anno() == fecha2.anno())
        return true;
    else
        return false;
}

bool operator !=(const Fecha& fecha1, const Fecha& fecha2)
{
    return !(fecha1 == fecha2);
}

bool operator <(const Fecha& fecha1, const Fecha& fecha2)
{
    if(fecha2.anno() > fecha1.anno())
        return false;
    else
    {
        if(fecha2.mes() > fecha1.mes())
            return false;
        else
        {
            if(fecha2.dia() >= fecha1.dia())
                return false;
            else
                return true;
        }
    }
}

bool operator >(const Fecha& fecha1, const Fecha& fecha2)
{
    return (fecha2 < fecha1);
}

bool operator <=(const Fecha& fecha1, const Fecha& fecha2)
{
    return !(fecha2 < fecha1);
}

bool operator >=(const Fecha& fecha1, const Fecha& fecha2)
{
    return !(fecha1 < fecha2);
}

void Fecha::validar()
{

    if (anno_ < Fecha::AnnoMinimo) 
        throw Invalida ("Anno invalido");
    
    if (anno_ > Fecha::AnnoMaximo)
        throw Invalida ("Anno invalido");

    switch (mes_)
    {
        case 1: case 3: case 5: case 7: case 8: case 10: case 12:
            if(dia_ > 31 || dia_ < 0)
                throw Invalida("Dia invalido");
        break;
        case 2:
            if(anno_ % 4 == 0 && (anno_ % 100 != 0 || anno_ % 400 == 0))
            {
                if(dia_ < 0 || dia_ > 29)
                    throw Invalida("Dia invalido");
            }
            else
            {
                if(dia_ < 0 || dia_ > 28)
                    throw Invalida("Dia invalido");
            }
        break;
        case 4: case 6: case 9: case 11:
            if(dia_ < 0 || dia_ > 30)
                throw Invalida("Dia invalido");
        break;
        default:
            throw Invalida("Mes invalido");
        break;
    }
}

long operator -(const Fecha& fecha1, const Fecha& fecha2) //fecha1 es menor que fecha2
{
    double diferencia;
    
    tm fech1 = {};
    tm fech2 = {};

    fech1.tm_mday = fecha1.dia();
    fech1.tm_mon = fecha1.mes() - 1;
    fech1.tm_year = fecha1.anno() - 1900;

    fech2.tm_mday = fecha2.dia();
    fech2.tm_mon = fecha1.mes() - 1;
    fech2.tm_year = fecha2.anno() - 1900;

    diferencia = difftime(mktime(&fech2), mktime(&fech1))/86400;

    return diferencia;
}

const char* Fecha::cadena() const
{
    static const char* dias[] = {"domingo", "lunes", "martes", "mi�rcoles", "jueves", "viernes", "s�bado"};
    static const char* meses[] = {"enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"};

    tm tiempo = {};

    tiempo.tm_mday = dia_;
    tiempo.tm_mon = mes_ - 1;
    tiempo.tm_year = anno_ - 1900;

    mktime(&tiempo);
    
    static char fecha[36];
    
    sprintf(fecha, "%s %d de %s de %d", dias[tiempo.tm_wday], dia_, meses[mes - 1], anno_);

    return fecha;
}
int Fecha::dia()const {return dia_;}
int Fecha::mes()const {return mes_;}
int Fecha::anno()const {return anno_;}

Fecha operator +(const Fecha& fecha1, int d)
{
    Fecha resultado(fecha1);
    resultado += d;
    
    return resultado;
}

Fecha operator -(const Fecha& fecha1, int d)
{
    Fecha resultado(fecha1);
    resultado += -d;
    
    return resultado;
}

//insercion de flujo
ostream& operator << (ostream& os, const Fecha& fecha1)
{
    os << fecha1.cadena();
    return os;
}

//extraccion de flujo
istream& operator >> (istream& is, Fecha& fecha1)
{
    char* fech = new char[11]{'\0'}; //La fecha tiene como m�ximo 11 caracteres contando el caracter terminador \0
    is.width(11); //se utiliza para que no haya desbordamiento
    is >> fech; //leemos la cadena fecha
    Fecha fecha2(fech); //creamos un objeto de tipo fecha y dicho objeto se lo asignamos a fecha1
    fecha1 = fecha2;
    delete [] fech; //se libera la memoria del puntero
    return is;
}
