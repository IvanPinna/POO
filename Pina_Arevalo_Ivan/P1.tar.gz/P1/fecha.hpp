#ifndef FECHA_HPP_
#define FECHA_HPP_

#include<iostream>
#include <ctime>
#include <stdio.h>

using namespace std;
class Fecha {
public:
    class Invalida
    {
    public:
        Invalida(const char* e) : error(e){}
        const char* por_que() const
        {
            return error;
        }
    private:
        const char* error;
    };

    explicit Fecha(int d = 0, int m = 0, int a = 0);
    Fecha(const char *); //indica que donde apunta el puntero es constante.

    static const int AnnoMinimo;
    static const int AnnoMaximo;


    Fecha& operator ++(); //Prefijo
    Fecha& operator --(); //Prefijo
    Fecha operator ++(int ); //Postfijo  ;  int sirve para diferenciar el metodo prefijo y el sufijo.
    Fecha operator --(int ); //Postfijo
    Fecha& operator +=(int n);
    Fecha& operator -=(int n);

    int dia() const;
    int mes() const;
    int anno() const;

    const char* cadena() const;

private:
    int dia_, mes_, anno_;
    void validar();
};

bool operator ==(const Fecha& fecha1, const Fecha& fecha2);
bool operator !=(const Fecha& fecha1, const Fecha& fecha2);
bool operator <(const Fecha& fecha1, const Fecha& fecha2);
bool operator >(const Fecha& fecha1, const Fecha& fecha2);
bool operator <=(const Fecha& fecha1, const Fecha& fecha2);
bool operator >=(const Fecha& fecha1, const Fecha& fecha2);
long operator -(const Fecha& fecha1, const Fecha& fecha2);//devuelve la diferencia en dias
Fecha operator +(const Fecha& fecha1, int dias);
Fecha operator -(const Fecha& fecha1, int dias);

ostream& operator<< (ostream& os, const Fecha& );
istream& operator>> (istream& os, Fecha& );
#endif // FECHA_HPP_









