//PRACTICA 1

#ifndef CADENA_HPP_
#define CADENA_HPP_
#include <iterator>
#include <iostream>
#include <functional>

using namespace std;
class Cadena
{
public:
    Cadena(size_t tam_ = 0, char s_ = ' '); //No se permite la conversion implicita(deberia ser explicit??), este constructor incluye el apartado a, b y c.
    Cadena(const char*); //apartado e
    Cadena(const char* , size_t ); //apartado f
    Cadena(const Cadena& , size_t , size_t npos = -1); //Parametro 1, cadena a copiar parcialmente, parametro 2 posicion inicial a parir de la cual se empieza a copiar, parametro 3, longitud a copiar
    //Constructores de copia
    Cadena& operator =(const Cadena& cadena1); //asignacion por copia
    Cadena(const Cadena& ); //Constructor de copia
    //Cosntructores de movimiento
    Cadena(Cadena&& ); //constructor de movimiento
    Cadena& operator =(Cadena&& ); //asignacion por movimiento

    Cadena& operator =(const char *);

    size_t length() const; //longitud de la cadena
    static const size_t npos = -1;

    Cadena& operator +=(const Cadena& );

    char& operator [](size_t ); //El parametro que tiene es el indice
    const char& operator [](size_t ) const;

    char& at(size_t );
    const char& at(size_t )const ;

    Cadena substr(size_t, size_t) const;

    const char* c_str()const; //conversion de Cadena a const char*
    ~Cadena();
    
    //Iteradores
    typedef char* iterator;
    typedef const char* const_iterator;
    typedef std::reverse_iterator<iterator> reverse_iterator;
    typedef std::reverse_iterator<const_iterator> const_reverse_iterator;

    iterator begin();
    iterator end();

    const_iterator begin() const;
    const_iterator end() const;

    const_iterator cbegin() const;
    const_iterator cend() const;

    reverse_iterator rbegin();
    reverse_iterator rend();

    const_reverse_iterator rbegin() const;
    const_reverse_iterator rend() const;

    const_reverse_iterator crbegin() const;
    const_reverse_iterator crend() const;

private:
    char* s_;
    unsigned tam_;
};

Cadena operator+(const Cadena& , const Cadena& );
bool operator ==(const Cadena& ,const Cadena& );
bool operator <(const Cadena& , const Cadena& );
bool operator >(const Cadena& , const Cadena& );

bool operator !=(const Cadena& cadena1, const Cadena& cadena2);

bool operator <=(const Cadena& , const Cadena& );
bool operator >=(const Cadena& , const Cadena& );

ostream& operator <<(ostream& os, const Cadena& );
istream& operator >>(istream& is, Cadena& );


namespace std{
    template <> struct hash <Cadena>{
        size_t operator() (const Cadena& cad) const
        { // conversión const char* ->string
          return hash<string>{}(cad.c_str());
        }
    };
}


#endif // CADENA_HPP_
