//PRACTICA 1

#include <iostream>
#include <stdlib.h>
#include <cstring>
#include <stdio.h>
#include <cassert>
#include <stdexcept>
#include <iomanip>
#include "cadena.hpp"

using namespace std;

Cadena::Cadena(size_t n, char c)
{
    size_t pos = 0;
    s_ = new char[n + 1];
    while(pos < n)
    {
        s_[pos] = c;
        pos++;
    }
    s_[pos] = '\0';
    tam_ = n;
}

Cadena::Cadena(const char* cadena_)
{
    size_t tam, i;
    tam = strlen(cadena_);

    s_ = new char [tam + 1];
    tam_ = tam;
    
    for(i = 0; i < tam; i++)
        s_[i] = cadena_[i];
    s_[i] = '\0';
}

Cadena::Cadena(const char* cadena_, size_t n)
{
    size_t tam, tam_final, i;
    tam = strlen(cadena_);

    if(tam < n) //hacemos esta comparacion para no crear la cedena con mas espacio de lo necesario en el caso de que n fuera mayor que cadena_
        tam_final = tam;
    else
        tam_final = n;

    tam_ = tam_final;
    s_ = new char[tam_final + 1];

    for(i = 0; i < n && cadena_[i] != '\0'; i++)
        s_[i] = cadena_[i];
    s_[i] = '\0';

}

Cadena::Cadena(const Cadena& cadena1, size_t inicio, size_t longitud)
{
    size_t tam, tam_final;

    tam = cadena1.tam_;

    if(inicio > cadena1.tam_)
        throw (std::out_of_range ("Posicion inicial fuera de rango"));
    else
    {
        if(longitud != npos)
        {
            if(tam - inicio > longitud)
                tam_final = longitud;
            else
                tam_final = tam - inicio;
        }
        else
            tam_final = tam - inicio;

        tam_ = tam_final;
        s_ = new char[tam_final + 1];
        size_t i;
        for(i = 0; i < tam_final; i++)
            s_[i] = cadena1[inicio+i];
        s_[i] = '\0';
    }
}

Cadena& Cadena::operator =(const char *cadena1)
{

    if(tam_ != strlen(cadena1))
    {
        tam_ = strlen(cadena1);
        delete[] s_;
        s_ = new char[tam_ + 1];
    }

    strcpy(s_, cadena1);
    s_[tam_ + 1] = '\0'; 

    return *this;
}

Cadena::Cadena(Cadena&& cad)
    : s_(cad.s_), tam_(cad.tam_)
{
    cad.s_ = nullptr;
    cad.tam_ = 0;
}

Cadena& Cadena::operator=(Cadena&& cad)
{
    delete[] s_;
    s_ = cad.s_;
    tam_ = cad.tam_;
    
    cad.s_ = nullptr;
    cad.tam_ = 0;
    
    return *this;
}
    
size_t Cadena::length() const
{
    return tam_;
}

Cadena& Cadena::operator+=(const Cadena& cadena2) //seria void o Cadena?
{
    tam_ += cadena2.tam_;
    char* aux = new char[tam_ + 1];
    
    strcpy(aux, s_);
    delete[] s_;
    s_ = aux;
    
    strcat(s_, cadena2.s_);
    
    return *this;
}

Cadena operator+(const Cadena& cadena1, const Cadena& cadena2)
{
    Cadena resultado(cadena1);
    resultado += cadena2;

    return resultado;
}

Cadena::Cadena(const Cadena& cadena1) : tam_{cadena1.tam_}
{
    s_ = new char[tam_ + 1];
    strcpy(s_, cadena1.s_);
}

Cadena& Cadena::operator =(const Cadena& cadena1)
{
    if(this != &cadena1)
    {
        delete[] s_;
        tam_ = cadena1.tam_;
        s_ = new char[tam_ + 1];
        strcpy(s_, cadena1.s_);
    }
    return *this;
}

bool operator ==(const Cadena& cadena1, const Cadena& cadena2)
{
    return strcmp(cadena1.c_str(), cadena2.c_str()) == 0;
}

bool operator <(const Cadena& cadena1, const Cadena& cadena2) //cadena1 < cadena2
{
    if (strcmp(cadena1.c_str(), cadena2.c_str()) < 0)
        return true;
    else
        return false;
}

bool operator >(const Cadena& cadena1, const Cadena& cadena2) //cadena1 > cadena2
{
    return strcmp(cadena1.c_str(), cadena2.c_str()) > 0;
}

bool operator !=(const Cadena& cadena1, const Cadena& cadena2) //cadena1 != cadena2
{
    return !(cadena1 == cadena2);
}

bool operator <=(const Cadena& cadena1, const Cadena& cadena2) //cadena1 <= cadena2
{
    return (cadena1 == cadena2 || cadena1 < cadena2);
}

bool operator >=(const Cadena& cadena1, const Cadena& cadena2)
{
    return (cadena1 == cadena2 || cadena1 > cadena2);
}

char& Cadena::operator [](size_t i)
{
    return s_[i]; //la funcion at comprueba si i est� dentro del rango
}
const char& Cadena::operator [](size_t i) const
{
    return s_[i]; //la funcion at comprueba si i est� dentro del rango
}

char& Cadena::at(size_t i)
{
    if(i >= tam_)
        throw (std::out_of_range ("Posicion fuera de rango"));
    else
        return s_[i];
}
const char& Cadena::at(size_t i) const
{
    if(i >= tam_)
        throw (std::out_of_range ("Posicion fuera de rango"));
    else
        return s_[i];
}

Cadena Cadena::substr(size_t indice_inicio, size_t tamanio) const
{
    Cadena nuevo;
    if(indice_inicio > tam_ - 1)
        throw (std::out_of_range("Posicion inicial fuera de rango"));
    else
    {
        if(tamanio > tam_ - indice_inicio)
            throw (std::out_of_range ("La subcadena supera los limites de la cadena"));
        else
        {
            delete[] nuevo.s_;
            nuevo.s_ = new char[tamanio + 1]; //+1 para almacenar el caracter terminador
            nuevo.tam_ = tamanio;

            for(size_t i = 0; i < tamanio; i++)
                nuevo.s_[i] = s_[indice_inicio + i];
        }
    }
    return nuevo;
}

const char* Cadena::c_str() const
{
    return s_;
}

Cadena::~Cadena()
{
    delete [] s_;
    s_ = 0;
}

ostream& operator <<(ostream& os, const Cadena& cadena1)
{
    os << cadena1.c_str();
    return os;
}

istream& operator >>(istream& is, Cadena& cadena1)
{
    /*char * cad = new char[32];
    is >> cad;
    Cadena cadena2(cad);
    delete[]cad;
    cadena1 = cadena2;
    return is;*/
    char* cad = new char[32]{'\0'};
    is >> std::setw(32) >> cad;

    // Este objeto es temporal, y se aprovecha el operador de
    // asignaci�n con movimiento.
    cadena1 = Cadena(cad);
    delete[] cad;
  
  return is;
}

Cadena::iterator Cadena::begin()
{
    return s_;
}

Cadena::const_iterator Cadena::begin() const
{
    return s_;
}

Cadena::const_iterator Cadena::cbegin() const
{
    return s_;
}

Cadena::reverse_iterator Cadena::rbegin()
{
    return reverse_iterator(end());
}

Cadena::const_reverse_iterator Cadena::rbegin() const
{
    return const_reverse_iterator(end());
}

Cadena::const_reverse_iterator Cadena::crbegin() const
{
    return const_reverse_iterator(cend());
}

Cadena:: iterator Cadena:: end()
{
    return s_ + tam_;
}

Cadena::const_iterator Cadena::end() const
{
    return s_ + tam_;
}

Cadena::const_iterator Cadena::cend() const
{
    return s_ + tam_;
}

Cadena::reverse_iterator Cadena::rend()
{
    return reverse_iterator(begin());
}

Cadena::const_reverse_iterator Cadena::rend() const
{
    return const_reverse_iterator(begin());
}

Cadena::const_reverse_iterator Cadena::crend() const
{
    return const_reverse_iterator(cbegin());
}
